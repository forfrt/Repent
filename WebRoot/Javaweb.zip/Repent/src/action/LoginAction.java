package action;

import java.sql.SQLException;

import pojo.Users;
import impl.UsersImpl;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport{
	private Users currentUser;

	public String execute(){
		
		UsersImpl userImpl=new UsersImpl();
		try {
			return userImpl.Login(currentUser);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "failed";		
	}

	public Users getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(Users currentUser) {
		this.currentUser = currentUser;
	}

}