package action;

import java.sql.SQLException;

import impl.UsersImpl;
import pojo.Users;

import com.opensymphony.xwork2.ActionSupport;

public class SignupAction extends ActionSupport{
	private Users currentUser;
	
	public String execute(){
		UsersImpl userImpl=new UsersImpl();
		try {
			return userImpl.signUp(currentUser);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
		
		return "failed";
	}
	
	public Users getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(Users currentUser) {
		this.currentUser = currentUser;
	}
}
