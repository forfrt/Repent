package impl;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.DBConn;

import pojo.Articles;

public class ArticlesImpl {
	public ArticlesImpl(){}
	
	public List<Articles> getFirstNArticles(int n) throws SQLException{
		System.out.println("------------impl.ArticlesImpl.getFirstNArticles method start------------");
		DBConn conn=new DBConn();
		
		String getFirstNArticlesSql="select * from news order by nTime desc limit 0,?;";
		PreparedStatement p=conn.getConnection().prepareStatement(getFirstNArticlesSql);
		p.setInt(1, n);
		System.out.println(p.toString());
		
		ResultSet set=p.executeQuery();
		return getListFromSet(set);
	}
	
	public List<Articles> getMoreNArticles(int n,int aId) throws SQLException{
		System.out.println("------------impl.ArticlesImpl.getMoreNArticles method start------------");
		DBConn conn=new DBConn();
		
		String getMoreNArticlesSql=
				"select * from news where nId < ? order by nId desc limit 0,?";
		PreparedStatement p=conn.getConnection().prepareStatement(getMoreNArticlesSql);
		p.setInt(1, aId);
		p.setInt(2, n);
		
		System.out.println(p.toString());
		
		ResultSet set=p.executeQuery();
		return getListFromSet(set);
	}
	
	private List<Articles> getListFromSet(ResultSet set) throws SQLException{
		System.out.println("------------impl.ArticlesImpl.getListFromSet method start------------");
		List<Articles> list=new ArrayList<Articles>();
		while(set.next()){
			Articles art=new Articles();
			art.setaId(set.getInt(1));
			System.out.print(set.getInt(1));
			
			art.setaTitle(set.getString(2));
			System.out.print(set.getString(2));
			
			art.setaContent((set.getString(3)));
			System.out.print(set.getString(3));
			
			art.setaTime((set.getTimestamp(4)));
			System.out.print(set.getTimestamp(4));
			
			art.setuId(set.getInt(5));
			System.out.print(set.getInt(5));
			
			art.setaBrCount(set.getInt(6));
			System.out.print(set.getInt(6));
			
			art.setaReCount(set.getInt(7));
			System.out.println(set.getInt(7));
			
			System.out.println();
			list.add(art);
		}
		return list;
	}
}