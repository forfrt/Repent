package impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.DBConn;
import pojo.Users;

public class UsersImpl {
	public UsersImpl(){}
	
	public String Login(Users user) throws SQLException{
		System.out.println("------------impl.UsersImpl.Login method start------------");
		System.out.println("鎻愪氦鍒癷mpl.UsersImpl.Login method涓殑user淇℃伅:\n"+user.Details());
		DBConn conn=new DBConn();
		
		String querySql="select * from user where uMail = ? ;";
		PreparedStatement querySta=conn.getConnection().prepareStatement(querySql);
		querySta.setString(1, user.getuEmail());
		
		System.out.println(querySta.toString());
		
		ResultSet querySet=querySta.executeQuery();
		querySet.next();//鎸囬拡鎸囧埌绗竴鏉¤褰�
		String dbPassword=querySet.getString(3);
		
		if(dbPassword.equals(user.getuPassword())){
//			System.out.println("琛ㄥ崟鎻愪氦瀵嗙爜: "+user.getuPassword()+" 涓�+"鏁版嵁搴撳瓨鍌ㄥ瘑鐮� "
//		+dbPassword+"鐩哥瓑~");
			querySta.close();
			conn.getConnection().close();
			return "success";
		}else{
			querySta.close();
			conn.getConnection().close();
			return "failed";
		}
	}
	
	public String signUp(Users user) throws SQLException{
		System.out.println("------------impl.UsersImpl.signup method start------------");
		System.out.println("鎻愪氦鍒癷mpl.UsersImpl.Login method涓殑user淇℃伅:\n"+user.Details());
		DBConn conn=new DBConn();
		
		String insertSql="insert into user(uName,uPwd,uMail) values(?,?,?)";
		PreparedStatement p=conn.getConnection().prepareStatement(insertSql);
		p.setString(1, user.getuName());
		p.setString(2, user.getuPassword());
		p.setString(3, user.getuEmail());
		
		try {
			p.execute();
			return "success";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			String strDBError="Error occur while using impl.UsersImpl.signUp() method:" +
					"The queryString is: "	+ insertSql.toString() +
					"<p>The Error Information from DBMS"+e.getMessage();
			System.out.println("strDBError");
			e.printStackTrace();
			return "failed";
		}finally{
			p.close();
			conn.getConnection().close();
		}
	}
	
	public Users getQuery(int uID) throws SQLException
	{
		Users  user = new Users();
		String sql = "SELECT uName,uPwd,uPhoto FROM USER WHERE uID = ?";
		
		Connection conn = new DBConn().getConnection();
		
		PreparedStatement psQuery = conn.prepareStatement(sql);
		
		ResultSet rs = null;
		
		rs = psQuery.getResultSet();
		
		while(rs.next())
		{
			user.setuName(rs.getString(1));
			user.setuPassword(rs.getString(2));
			user.setPhoto(rs.getBlob(3));
		}
		rs.close();
		psQuery.close();
		conn.close();
		
		return user;
	}
}
