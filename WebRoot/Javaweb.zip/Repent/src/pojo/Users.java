package pojo;

import java.sql.Blob;
import java.sql.Date;

public class Users {
	public int uId;
	public String uName;
	public String uPassword;
	public String uEmail;
	public String remember_me;
	public Blob uPhoto;
	
	
	public int getuId() {
		return uId;
	}
	public void setuId(int uId) {
		this.uId = uId;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuPassword() {
		return uPassword;
	}
	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}
	public String getuEmail() {
		return uEmail;
	}
	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}
	public String getRemember_me() {
		return remember_me;
	}
	public void setRemember_me(String remember_me) {
		this.remember_me = remember_me;
	}
	public void setPhoto(Blob photo)
	{
		this.uPhoto = photo;
	}
	public Blob getPhoto()
	{
		return uPhoto;
	}
	
	public String Details(){
		return "+------+------------+--------------------------------+---------------+--------+--------------------+------------+\n" +
				"| uId  | uName      | uPassword                      | uEmail             | remeber_me |\n" +
				"+------+------------+--------------------------------+---------------+--------+--------------------+------------+\n" +
				"|"+String.format("%-6d",this.getuId())+"|"+String.format("%-12s",this.getuName())+
				"|"+String.format("%-32s",this.getuPassword())+"|"+String.format("%-20s", this.getuEmail())+
				"|"+String.format("%-12s",this.getRemember_me())+"|";
	}
	
}
