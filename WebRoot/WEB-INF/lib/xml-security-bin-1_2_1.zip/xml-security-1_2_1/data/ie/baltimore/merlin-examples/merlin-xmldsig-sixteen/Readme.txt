Example Signature[1]

[1] http://www.w3.org/Signature/Drafts/xmldsig-core/Overview.html

See signature.xml

This includes internal and external base 64, references of the forms
"", "#xpointer(/)", "#foo" and "#xpointer(id('foo'))" (with and
without comments), manifests, signature properties, simple xpath
with here(), xslt, retrieval method and odd interreferential
dependencies.

Included in the directory are:

  signature.xml - The signature itself
  signature.tmpl - The template from which the signature was created
  c14n-*.txt - All intermediate c14n output

Merlin Hughes <merlin@baltimore.ie>
Baltimore Technologies, Ltd.

Tuesday, April 10, 2001
